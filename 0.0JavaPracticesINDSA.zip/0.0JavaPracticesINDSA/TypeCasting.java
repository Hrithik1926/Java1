public class TypeCasting {
    public static void main(String[] args) {
        char a='a';
        char b='A';
//        int i=(int)'a';
//        int j=(int)'A';
        float i=(float)'a';
        float j=(float)'A';
        for (i='a';i<'z';i++){
            if (i=='z'){

                break;
            }
            System.out.println(i);
        }


        System.out.println("Capital Letter Series of ABCD");
//        System.out.println(i);
        for (j='A';j<'Z';j++){
            if (j=='Z'){

                break;
            }
            System.out.println(j);
        }
//        System.out.println(i);
    }
}
