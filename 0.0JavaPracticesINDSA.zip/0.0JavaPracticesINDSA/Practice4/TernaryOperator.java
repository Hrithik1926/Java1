package Practice4;

public class TernaryOperator {
    public static void main(String[] args) {


        int a = 8, b = 6;
        boolean x = (a > b) ? true : false;
        int y = (a < b) ? b : a;
        System.out.println(x);
        System.out.println(y);


    }
}