import java.util.*;

public class WhileLoop2 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int count=1;
        while (count<=1000){
            System.out.print(count+" ");
            count++;

        }
        System.out.println();
    }
}
