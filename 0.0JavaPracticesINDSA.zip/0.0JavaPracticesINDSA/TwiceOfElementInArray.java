public class TwiceOfElementInArray {
    public static boolean twiceArray(int nums[]){
        for (int i=0;i< nums.length;i++){
            for (int j=i+1;j< nums.length;j++){
                if (nums[i]==nums[j]){
                    return true;
                }
            }
        }
        return false;
    }
    public static void main(String[] args) {
        int nums[]={2,4,1,6};
        System.out.println(twiceArray(nums));

    }
}
