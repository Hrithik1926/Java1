import java.util.*;
public class Exercise2 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        double temp=103.5;
        if (temp>100){
            System.out.println("Fever");
        }else {
            System.out.println("Not Fever");
        }

    }
}
