import java.util.*;
public class WhileLoop {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        long n=sc.nextLong();
        long i=0L;
        while (i<n){
            System.out.println("Hello MERN"+i);
            i++;
        }
    }
}
