package PracticeArray2;

import java.util.Scanner;

public class CreateArray {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int num[]=new int[n];
        for (int i=0;i<n;i++){
            num[i]=sc.nextInt();

        }
        for (int i=0;i<n;i++){
            System.out.print(num[i]+" ");
        }
        System.out.println();
        System.out.println("The length of array is :"+num.length);
    }

}
