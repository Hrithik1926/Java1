package PracticeArray2;

public class S1 {
    public static int s2(int num[],int key){
        for (int i=0;i< num.length;i++){
            if (num[i]==key){
                return i;

            }
        }
        return -1;
    }
    public static void main(String[] args) {
        int num[]={4,1,2,5,6,3,9,8,7};
        int key=77;
        int s=s2(num,key);
        if (s==-1){
            System.out.println("Not found");
        }else{
            System.out.println(key+" is found at index of "+s);
        }

    }
}
