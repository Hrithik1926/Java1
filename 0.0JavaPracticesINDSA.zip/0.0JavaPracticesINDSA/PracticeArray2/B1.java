package PracticeArray2;

import java.util.Scanner;

public class B1 {
    public static int b1(int num[],int key){
        int sart=0,end= num.length-1;
        while(sart<=end){
            int mid=(sart+end)/2;
            if (num[mid]==key){
                return mid;
            }
            if (num[mid]>key) {
                end--;
            }else {
                sart++;
            }
        }
        return -1;
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);

        int num[]={1,2,3,4,5,6,7,8,9,10,12,13,14,15,19};
        System.out.print("Enter the Key :");
        int key=sc.nextInt();
       int c= b1(num,key);
        if (c==-1){
            System.out.println("NOT FOUND");
        }
        else {
            System.out.println(key+" is found at index of :"+c);
        }
    }
}
