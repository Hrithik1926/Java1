package PracticeArray2;

import java.util.Scanner;

public class SearchKey {
    public static int  subArray(int num[],int key){
        for (int i=0;i<=num.length;i++){

            if (num[i]==key){
                return i;
            }

        }

           return -1;


    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);

        int num[]={1,4,5,6,9,8,7,3,2,10};
        System.out.print("Enter the Key :");
        int key=sc.nextInt();
      int n=  subArray(num,key);
      if (n==-1){
          System.out.println("not found");


      }else {
          System.out.println("The key "+key+" is found at index of : "+n);
      }

    }
}
