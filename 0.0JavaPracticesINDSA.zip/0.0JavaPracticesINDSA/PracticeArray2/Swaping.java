package PracticeArray2;

public class Swaping {
    public static void s(int num[]){
        int start=0,end= num.length-1;

       while (start<end){
         int temp=num[end];
           num[end]=num[start];
           num[start]=temp;
           start++;
           end--;
       }

    }
    public static void main(String[] args) {
        int num[]={1,8,6,4,5,7,9};
        s(num);
        for (int i=0;i< num.length;i++){
            System.out.print(num[i]+" ");
        }
        System.out.println();
    }
}
