package PracticeArray2;

public class ParingOfArray {
    public static void pair(int num[]){
        int top=0;
        for (int i=0;i<num.length;i++){
            int n=num[i];
            for (int j=i+1;j< num.length;j++){
                System.out.println("("+n+","+num[j]+")");
                top++;
            }
            System.out.println();
        }
        System.out.println(top);
    }
    public static void main(String[] args) {
        int num[]={1,2,4,5,6,3,9,8,7,4,5,6,1,2,3,6,5,4,6,8,9,95};
        System.out.println(num.length);
        pair(num);
    }
}
