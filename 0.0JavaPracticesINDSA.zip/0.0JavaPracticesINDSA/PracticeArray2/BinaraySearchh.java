package PracticeArray2;

import java.util.Scanner;

public class BinaraySearchh {
    public  static int sun(int num[],int key){
        int start=0,end= num.length-1;
while (start<=end){
    int mid=(start+end)/2;

    if (num[mid]==key){
        return mid;
    }
    if (num[mid]>key){
        end--;
    }
    else {
        start++;
    }
        }
return -1;
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int num[]={1,2,3,6,9,11,12,14,16,18};
        System.out.print("Enter the Key :");
        int key=sc.nextInt();
int t=sun(num,key);
if (t==-1){
    System.out.print("Not found");
}else{
    System.out.print("the index of the number is :"+t);
}

    }
}
