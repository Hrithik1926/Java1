package PracticeArray2;

public class SubArray {
    public static void sub(int num[]){
        int top=0;
        for (int i=0;i<=num.length;i++){
            for (int j=i;j<= num.length;j++){
                for (int k=i;k<j;k++){
                    System.out.print(num[k]+" ");
                }
                top++;
                System.out.println();
            }
            System.out.println();
        }
        System.out.println(top);
    }
    public static void main(String[] args) {
        int num[]={1,5,2,6,4,3,9,8,7,5};
        sub(num);
        System.out.println();
    }
}
