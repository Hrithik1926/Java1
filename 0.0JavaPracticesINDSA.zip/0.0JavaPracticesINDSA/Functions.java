public class Functions {
    public static void hello(){
        System.out.println("Hello MERN This is Ritik Meena");
        System.out.println("This is the Second Revesion of Java And DSA.");
    }

    public static void main(String[] args) {
        hello();
    }
}
