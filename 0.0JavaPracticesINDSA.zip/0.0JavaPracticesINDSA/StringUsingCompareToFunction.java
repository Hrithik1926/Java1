public class StringUsingCompareToFunction {
    public static void main(String[] args) {
        String fruits[]={"apple","aanana","aange","Rpaya","arapes"};
        String largest=fruits[0];
    /*
      compareTo() :- is treat the alphabet equal in terms of Capital  or Small
     Like:-
      A==a
      B==b


      for (int i=1;i< fruits.length;i++){
           if (largest.compareTo(fruits[i])<0){
                largest=fruits[i];
            }
        }

     */
        /*
         compareToIgonreCase() :- is treat the alphabet not equal in terms of Capital  or Small
     Like:-
      A!=a in which A is greater
      B!=b in which B is greater
         */
        for (int i=1;i< fruits.length;i++){
            if (largest.compareToIgnoreCase((fruits[i]))<0){
                largest=fruits[i];
            }
        }
        System.out.println(largest);
    }
}
