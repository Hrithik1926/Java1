import java.util.*;
public class Billing {
    public static void main(String[] args) {
        float Pricepen=7;
        float Pricepenile=2;
        float Priceeraser=3;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number of Pen:");
        int pen=sc.nextInt();
        System.out.println("Enter the number of Pencile:");
        int penile=sc.nextInt();
        System.out.println("Enter the number of eraser:");
        int eraser=sc.nextInt();
        double bill=(pen*Pricepen)+(Pricepenile*penile)+(Priceeraser*eraser);

        double GST=bill+bill*28/100;
        System.out.println("The Total Amount is: "+bill);
        System.out.println("Include 28% GST :"+GST);
    }
}
