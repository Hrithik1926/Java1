import java.util.*;
public class areaOfCircle {
    public static void main(String[] args) {
        Scanner sc =new Scanner(System.in);
        System.out.println("Enter the Radius of Circle ");
        float r= sc.nextFloat();
        double area=3.14*r*r;
        System.out.println(area);
    }

}
