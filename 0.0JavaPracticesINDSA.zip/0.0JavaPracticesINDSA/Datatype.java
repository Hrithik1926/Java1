public class Datatype {
    public static void main(String[] args) {
        byte b=8;
        short s=254;
        int i=5484;
        char ch='A';
        boolean bh=false;
        float f=42.3f;
        double d=265.264654d;
        long l=2653568652L;
        System.out.println(b);
        System.out.println(ch);
        System.out.println(s);
        System.out.println(f);
        System.out.println(d);
        System.out.println(bh);
        System.out.println(l);
        System.out.println(i);


    }
}
