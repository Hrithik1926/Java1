public class For1 {
    public static void loop(){
        for (int i=0;i<100000000;i++){
            System.out.println("*");
        }
    }
    public static void main(String[] args) {
        for (int i=0;i<10;i++){
            System.out.println("Hello MERN");
        }
loop();    }
}
