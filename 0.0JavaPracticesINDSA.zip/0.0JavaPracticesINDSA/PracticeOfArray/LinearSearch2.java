package PracticeOfArray;

import java.util.Scanner;

public class LinearSearch2 {
    public static int subArray(int num[],int key){
        for (int i=0;i<num.length;i++){
            if (num[i]==key){
                return i;
            }
        }
       return -1;
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the Size of Array:");
        int n=sc.nextInt();
        System.out.print("Enter the Key Value");
        int key=sc.nextInt();
        int num[]=new int[n];
        for (int i=0;i<n;i++){
            num[i]=sc.nextInt();
        }
        int a=subArray(num,key);
            if (a==-1){
                System.out.print("Key os not Found");
            }else {
                System.out.println(key+", is found at in index of:"+a);
            }

        }
    }

