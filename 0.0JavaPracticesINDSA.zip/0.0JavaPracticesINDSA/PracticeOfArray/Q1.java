package PracticeOfArray;

public class Q1 {
    public static int subArray(int n){
        n=56;
//        System.out.println(n);
        return n;
    }
    public static void main(String[] args) {
        //Pasing by value
       int n=4;
        System.out.println(n);
        subArray(5);
    }
}
