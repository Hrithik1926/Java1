package PracticeOfArray;

import java.util.Scanner;

public class l1 {
    public static void main(String[] args) {


    Scanner sc=new Scanner(System.in);
    int n=sc.nextInt();
    int linear[]=new int[n];
    for (int i=0;i<n;i++){
        int key=4;
        if (key==i){
            System.out.print("Key is Found:"+i);
        }else{
            System.out.println("Not found");
        }
    }

}
    }