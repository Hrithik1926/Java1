package PracticeOfArray;

import java.util.Scanner;

public class LinearSearchs {
    public static int  subArray(int num[],int key) {

for (int i=0;i< num.length;i++){
    if (num[i]==key){
        return i;
    }
}
        return -1;

    }
        public static void main (String[]args){
            Scanner input = new Scanner(System.in);
            int n = input.nextInt();
            int key=6;
            int num[] = new int[n];
            for (int i = 0; i < n; i++) {
                num[i] = input.nextInt();
            }
           int linear= subArray(num,key);
            if (linear==-1){
                System.out.println("Key is not Found");
            }else {
                System.out.println(linear);
            }

        }
    }
