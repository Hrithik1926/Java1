package PracticeOfArray;

import java.util.Scanner;

public class LinearSearch {
    public static void main(String[] args) {


        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int key=sc.nextInt();

        int num[] = new int[n];
        for (int i=0;i< num.length;i++){
//           / num[i]=sc.nextInt();
            if (i==key){
                System.out.println(i);
            }else{
                System.out.println("The key Does not Exit");
            }
        }
        for (int i=0;i< num.length;i++){
            System.out.print(num[i]);

        }


    }
}