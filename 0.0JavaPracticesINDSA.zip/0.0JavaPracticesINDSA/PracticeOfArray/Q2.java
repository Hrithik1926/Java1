package PracticeOfArray;

public class Q2 {
    public static void subArray(){
       int n[]=new int[0];
n[0]=5;
        System.out.println(n[0]);

    }
    public static void main(String[] args) {
        int n=2;
        System.out.println(2);
        subArray();
    }
}
