package PracticeOfArray;

import java.util.Scanner;

public class SwapingMethod {
    public static void swaping(int num[]){

        int first=0,last=num.length-1;
        while (first<last) {
            int temp = last;
            last = first;
            first = temp;
            first++;
            last--;
        }
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);

        int num[]={1,3,6,5,4,9,8,7};
        swaping(num);
        for (int i=0;i< num.length;i++){
    System.out.print(num[i]);
}
        System.out.println();

    }
}
