package PracticeOfArray;

import java.util.Scanner;

public class CreateArray {
    Scanner sc=new Scanner(System.in);

    public static void main(String[] args) {




    int n[]=new int[5];
    n[0]=5;
    n[1]=4;;
    n[2]=6;
    n[3]=9;
        System.out.println(n[0]);
        System.out.println(n[3]);
        System.out.println(n[1]);
        System.out.println(n[2]);


}}
