package PracticeOfArray;

public class ForEach {
    public static void main(String[] args) {
        int n[]={1,2,3,6,5,4,9,8,7,6,4,5};
        for (int i:n){
            System.out.println(i);
        }
    }
}
