import java.util.*;
public class Exercise4 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int a = 63, b = 36;
        boolean x = (a < b ) ? true : false;
        int y= (a > b ) ? a : b;
        System.out.println(x);
        System.out.println(y);
    }
}
