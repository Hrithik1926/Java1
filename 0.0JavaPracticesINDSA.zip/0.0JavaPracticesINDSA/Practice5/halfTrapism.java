package Practice5;

public class halfTrapism {
}
