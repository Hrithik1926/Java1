package Practice5;

public class Q1 {
    public static void main(String[] args) {

                for(int i = 0; i <= 5; i++ ) {
                    System.out.println("i = " + i );
                }
                System.out.println("i after the loop = ");
            }

        }

