public class SubStrings {
   //This function  is bulid by us.
    public static String substring(String str,int si ,int ei){
        String substein="";
        for (int i=si;i<ei;i++){
            substein+=str.charAt(i);
        }
return substein;
    }
    //InBuild Function
    public static void main(String[] args) {
        String str="VolvoCar";
        System.out.println(str.substring(4,7));
        System.out.println(substring(str,2,6));
    }
}
