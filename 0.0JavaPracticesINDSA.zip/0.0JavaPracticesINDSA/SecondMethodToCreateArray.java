public class SecondMethodToCreateArray {
    public static void main(String[] args) {
        double num[]={1.2,15.1,153.2,64};
        System.out.println(num[0]);
        System.out.println(num[1]);
        System.out.println(num[2]);
        System.out.println(num[3]);
    }
}
