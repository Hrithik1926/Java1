public class Swapp {
    public static void value(int a){
        a=54;
        System.out.println(a);
    }

    public static void main(String[] args) {
        int a=6;
        value(a);
        System.out.println(a);
    }
}
