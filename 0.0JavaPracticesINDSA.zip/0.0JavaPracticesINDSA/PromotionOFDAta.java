public class PromotionOFDAta {
    public static void main(String[] args) {
        int a=45;
        short b=1545;
        float c=4545f;
        float d=(byte)(a+b+c);
        System.out.println(d);
    }
}
