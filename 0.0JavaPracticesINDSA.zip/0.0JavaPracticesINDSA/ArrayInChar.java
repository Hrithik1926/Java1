import java.util.Scanner;

public class ArrayInChar {
    public static void main(String[] args) {
//        char name[]={'a','b','c','d','e','f'};
//        for (int i=0;i< name.length;i++){
//            System.out.println(name[i]);
//        }
    }
}
