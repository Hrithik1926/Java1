public class Sum {
    public static void main(String[] args) {
        int a=1545;
        float b=4542.21f;
        float sum=a+b;
        System.out.println(sum);


    }
}
