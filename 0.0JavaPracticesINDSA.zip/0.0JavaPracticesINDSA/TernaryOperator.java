import java.util.*;

public class TernaryOperator {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int num=sc.nextInt();
        String var=((num%2==0))?"Even":"Odd";
        System.out.println(var);
    }
}
