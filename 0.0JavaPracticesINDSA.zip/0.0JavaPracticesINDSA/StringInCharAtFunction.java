import java.util.Scanner;

public class StringInCharAtFunction {
    public static void charAtFunctionInString(String name){
        for (int i=0;i<name.length();i++){
            System.out.print(name.charAt(i));
        }


    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String name=sc.nextLine();
        System.out.println(name.length());
        charAtFunctionInString(name);
    }
}
