package Backtracking;

public class FindSubSet {
    public static void subsetStr(String str,String ans,int i){
        if (i==str.length()){
            System.out.print(ans+" ");
            return;
        }

        //Yes
        subsetStr(str,ans+str.charAt(i),i+1);
        //No
        subsetStr(str,ans,i+1);

    }

    public static void main(String[] args) {
        String str="Ritik";
        subsetStr(str,"",0);



    }
}
