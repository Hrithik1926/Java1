package Backtracking.Revision;

public class Subset {
    public static void change(String name,String ans,int i){
        if (i==name.length()){
            System.out.print(ans+" ");
            return;
        }

        change(name,ans+name.charAt(i),i+1);
        change(name,ans,i+1);
    }
    public static void main(String[] args) {
        String name="Ritik";
        change(name,"",0);
    }
}
