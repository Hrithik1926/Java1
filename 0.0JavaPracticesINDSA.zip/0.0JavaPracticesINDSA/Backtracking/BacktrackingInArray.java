package Backtracking;

public class BacktrackingInArray {
    public static void chaneArray(int num[],int i,int value){
        if (i== num.length){
            print(num);
            return;
        }
        num[i]=value;
        chaneArray(num,i+1,value+1);
        num[i]=num[i]-2;
    }
    public static void print(int num[]){
        for (int i=0;i< num.length;i++){
            System.out.print(num[i]+" ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        int num[]=new int[5];
        chaneArray(num,0,1);
        print(num);
    }
}
