import java.util.Scanner;

public class Strings {
    public static void main(String[] args) {
//        String name[] = {"Ritik", "Rupesh", "Simmi", "Arvind"};
//        System.out.print(name[0]+" , ");
//        System.out.print(name[1]+" , ");
//        System.out.print(name[2]+" , ");
//        System.out.print(name[3]+".");
//        for (int i=0;i< name.length;i++){
//            System.out.println(name[i]);
//        }


        //Concetitation
        String firstname="Ritik";
        String Lastname="Meena";
        String FullName=firstname+" "+Lastname;
        System.out.println(FullName);
    }
}