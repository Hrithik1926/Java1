import java.util.*;
public class EvenNumbers {
    public static void main(String[] args) {
//        Scanner sc=new Scanner(System.in);
//        int n=9;
        for (int i=9;i<100;i++){
            if (i%2==0){
                System.out.println(i);
            }
        }
    }
}
