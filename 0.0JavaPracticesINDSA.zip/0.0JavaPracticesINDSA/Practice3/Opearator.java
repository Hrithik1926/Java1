package Practice3;

public class Opearator {
    public static void main(String[] args) {
        int x=5,y=3;
        int a1=(x*y/x);
        float a2=(float)(x*(y/x));
        System.out.println(a1);
        System.out.println(a2);
    }
}
