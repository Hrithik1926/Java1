package PracticeOfOPPs;
class Student{
    String name;
    int roll;

}
public class P1 {
    public static void main(String[] args) {


        Student s = new Student();
        s.name = "Ritik";
        System.out.println(s.name);
        System.out.println(s.roll=45);

    }
}