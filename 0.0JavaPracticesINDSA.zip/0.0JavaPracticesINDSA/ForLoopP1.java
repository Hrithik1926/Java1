public class ForLoopP1 {
    public static void main(String[] args) {
        for (int i=1;i<12-2;i++){
            System.out.println(i+"  "+i);
            for (int j=i;j<12-1;j++){
                System.out.println(j);
            }
        }
    }
}
