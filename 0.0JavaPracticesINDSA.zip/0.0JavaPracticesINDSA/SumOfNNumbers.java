import java.util.*;
public class  SumOfNNumbers {
    public static void main(String[] args) {
        Scanner ritik=new Scanner(System.in);
       int num=ritik.nextInt();
       int va=1,sum=0;
while(va<=num){
    sum=sum+va;
    va++;
}
        System.out.println(sum);
    }
}
