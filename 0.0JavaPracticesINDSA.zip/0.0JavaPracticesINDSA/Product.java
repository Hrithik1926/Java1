import java.util.*;
public class Product {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
//        int a=464;
//        float b=12242.1f;
        int a=sc.nextInt();
        float b=sc.nextFloat();
        double product=a*b;
        System.out.println(product);
    }
}
