import java.util.Scanner;

public class ThirdMethodToCreateArrayByTakingInput {
    public static void main(String[] args) {
        //Taking Input Integer In the Array
        Scanner sc = new Scanner(System.in);
       int num[]=new int[5];
       num[0]=sc.nextInt();
       num[1]=sc.nextInt();
       num[2]=sc.nextInt();
       num[3]=sc.nextInt();
        System.out.print(num[0]+" "+num[1]+" "+num[2]+" "+num[3]);














    /*    int size = sc.nextInt();
        int  name[] = new int[size];
        for (int i = 0; i < size; i++) {
            name[i] = sc.nextInt();
        }

        for (int i = 0; i < size; i++) {
            System.out.print(name[i]+" ");
        }
        System.out.println();

     */


    }
}
