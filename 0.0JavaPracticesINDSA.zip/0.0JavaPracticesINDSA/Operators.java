public class Operators {

    public static void main(String[] args) {
        int x = 2, y = 55;
        int exp1 = (x * y / x);
        int exp2 = (x * (y / x));
        System.out.print(exp1 + ",");
        System.out.print(exp2);
    }
}
