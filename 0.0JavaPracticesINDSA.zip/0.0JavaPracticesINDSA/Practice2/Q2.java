package Practice2;

import java.util.Scanner;

public class Q2 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        double side=sc.nextDouble();
        double area=side*side;
        System.out.println(area);
    }
}
