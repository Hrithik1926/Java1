package Practice2;
import java.util.*;
public class Q4 {
    public static void main(String[] args) {
        byte b=4;
        char c='a';
        short s=512;
        int i=1000;
        float f=3.14f;
    double d=94.3226;
    double result=(f*b)+(i%c)-(d*s);
        System.out.println(result);
        int $=24;
        System.out.println($);
        double num=Math.random();
        System.out.println(num);
    }
}
