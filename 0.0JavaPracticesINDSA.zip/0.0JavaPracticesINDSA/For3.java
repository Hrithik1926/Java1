public class For3 {
    public static void main(String[] args) {
        for (int line=1;line<=4;line++){
            System.out.println("****");
        }
    }
}
