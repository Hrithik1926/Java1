public class DataTypeQ1 {
    public static void main(String[] args) {
        byte b=4;
        char ch='a';
        short s=512;
        int i=100;
        float f=3.14f;
        double d=999.6458;
        int result= (int) ((f*b)+(i%ch)-(d*s));
        System.out.println(result);
        //Just

    }
}
