public class doWhileLoop {
    public static void main(String[] args) {
        int n=0;
     do {
         System.out.println("Hello MERN");
         n++;
     }while (n<10);
    }
}
