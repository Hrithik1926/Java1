import java.util.*;
public class Input {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int a=sc.nextInt();
        byte b= sc.nextByte();;
        float ch=sc.nextFloat();
        short d=sc.nextShort();
        boolean e=sc.nextBoolean();
        double f=sc.nextDouble();
        long g=sc.nextLong();
        String h=sc.next();
        System.out.println(a);
        System.out.println(b);
        System.out.println(ch);
        System.out.println(d);
        System.out.println(e);
        System.out.println(f);
        System.out.println(g);
        System.out.println(h);



    }
}
