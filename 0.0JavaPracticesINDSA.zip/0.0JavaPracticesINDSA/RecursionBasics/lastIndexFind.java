package RecursionBasics;

public class lastIndexFind {
    public static int last(int num[],int key,int i){
        if (i== num.length){
            return -1;
        }
        int isfound=last(num,key,i+1);
        if (isfound==-1 &&num[i]==key){
            return i;
        }
        return isfound;
    }
    public static void main(String[] args) {
        int num[]={4,8,3,7,9,4,1};
        System.out.println(last(num,4,0));;
    }
}
