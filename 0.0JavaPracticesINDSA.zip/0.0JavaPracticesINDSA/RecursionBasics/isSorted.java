package RecursionBasics;

public class isSorted {
    public static boolean sorted(int num[],int i){
        if (i== num.length-1){
            return true;
        }
        if (num[i]>=num[i+1]){
            return false;
        }
        return sorted(num,i+1);
    }
    public static void main(String[] args) {
        int num[]={4,7,18,9};
        System.out.println(sorted(num,0));
    }
}
