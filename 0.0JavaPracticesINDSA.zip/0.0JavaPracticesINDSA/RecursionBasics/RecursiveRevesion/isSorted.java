package RecursionBasics.RecursiveRevesion;

public class isSorted {
    public static boolean isSort(int num[],int i){
        //Base Case
        if (i== num.length-1){
            return true;
        }
        if (num[i]>=num[i+1]){
            return false;
        }
        //Inner Call And Kaam
        return isSort(num,i+1);
    }

    public static void main(String[] args) {
        int num[]={5,6,8};
        System.out.println(isSort(num,0));
    }
}
