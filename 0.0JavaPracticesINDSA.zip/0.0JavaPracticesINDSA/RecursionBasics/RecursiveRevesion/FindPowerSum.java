package RecursionBasics.RecursiveRevesion;

public class FindPowerSum {
    public static int power(int n,int x){
        //BAse CAse
        if (x==1){
            return n;
        }
        //Inner Call
        return n*power(n,x-1);
    }

    public static void main(String[] args) {
        System.out.println(power(2,3));
    }
}
