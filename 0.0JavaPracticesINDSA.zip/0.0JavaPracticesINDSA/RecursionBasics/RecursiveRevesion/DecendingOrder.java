package RecursionBasics.RecursiveRevesion;

public class DecendingOrder {
    public static void  dec(int n){

        //Base Case
        if (n==1){
            System.out.print(n);
            return;
        }
        //Kaam
        System.out.print(n+" ");
        //inner Call
        dec(n-1);


    }
    public static void main(String[] args) {
        dec(6 );
    }
}
