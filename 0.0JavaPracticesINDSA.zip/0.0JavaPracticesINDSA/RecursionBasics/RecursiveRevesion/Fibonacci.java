package RecursionBasics.RecursiveRevesion;

public class Fibonacci {
    public static int fi(int n){
        //Base Case
        if (n==0 || n==1){
            return 1;
        }
        //Inner Call
        int a=fi(n-1);
        int b=fi(n-2);
        //Kaam
        int c=a+b;
        return c;
    }
    public static void main(String[] args) {
        System.out.println(fi(5));
        System.out.println(fi(3));
        System.out.println(fi(9));
        System.out.println(fi(8));
        System.out.println(fi(6));
        System.out.println(fi(2));
    }
}
