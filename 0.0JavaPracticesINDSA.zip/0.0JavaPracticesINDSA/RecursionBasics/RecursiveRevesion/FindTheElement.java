package RecursionBasics.RecursiveRevesion;

public class FindTheElement {
    public static int isFound(int num[],int key,int i){
        //Base Case
        if (i== num.length){
            return -1;
        }
        if (num[i]==key){
            System.out.print("The Key "+key+" is found At the Index of : ");
            return i;
        }

        //Inner CAll
       return isFound(num,key,i+1);

    }
    public static void main(String[] args) {
        int num[]={4,8,6,2,3,8,7,9};
        System.out.println(isFound(num,2,0));
    }
}
