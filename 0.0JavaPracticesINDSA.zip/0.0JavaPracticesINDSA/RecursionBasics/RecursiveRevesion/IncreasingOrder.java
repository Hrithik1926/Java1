package RecursionBasics.RecursiveRevesion;

public class IncreasingOrder {
    public static void In(int n){
        //Base case
        if (n==1){
            System.out.print(n+" ");
            return;
        }
        //Inner Call
        In(n-1);
        //Kaam
        System.out.print(n+" ");
    }
    public static void main(String[] args) {
        In(9);
    }
}
