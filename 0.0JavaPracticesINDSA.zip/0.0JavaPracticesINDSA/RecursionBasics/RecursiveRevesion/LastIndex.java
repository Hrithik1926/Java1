package RecursionBasics.RecursiveRevesion;

public class LastIndex {
    public static int inLast(int num[],int key,int i){
        if (i== num.length){
            return -1;
        }
        int in=inLast(num,key,i+1);

        if (in==-1 && num[i]==key){
            return i;
        }
        return in;
    }
    public static void main(String[] args) {
        int num[]={4,8,7,5,2,6,1,3,5,6,8,4,1};
        System.out.println(inLast(num,3,0));
    }
}
