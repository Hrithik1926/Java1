package RecursionBasics.RecursiveRevesion;

public class SumOFNNaturalNumber {
    public static int sum(int n){

        //Base Case
        if (n==1){
            return 1;
        }


        //Inner call
        int s=sum(n-1);
        int sa=n+s;
        //Kaam
        return sa;
    }
    public static void main(String[] args) {
        System.out.println(sum(9));
    }
}
