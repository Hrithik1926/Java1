package RecursionBasics;

public class ParingOfFriends {
    public static int pairWays(int n){
        if (n==1 || n==2){
            return n;
        }
        /*Single
        int a=pairWays(n-1);
        //Pair
       int b= pairWays(n-2);
        int c=a*b;
        int total=a+c;
        return total;

         */
        return pairWays(n-1)+(n-1)*pairWays(n-2);
    }
    public static void main(String[] args) {
        System.out.println(pairWays(5));
    }
}
