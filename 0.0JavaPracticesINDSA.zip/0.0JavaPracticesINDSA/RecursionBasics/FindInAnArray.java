package RecursionBasics;

public class FindInAnArray {
    public static int first(int num[],int key,int i){
        if (i==num.length){
            return -1;
        }
        if (num[i]==key){
            return i;
        }
      return  first(num,key,i+1);
    }
    public static void main(String[] args) {
        int num[]={4,8,6,1,3,5,8,9,7};

        System.out.println(first(num,1,0));
    }
}
