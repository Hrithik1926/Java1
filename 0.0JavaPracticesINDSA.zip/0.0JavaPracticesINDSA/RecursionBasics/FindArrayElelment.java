package RecursionBasics;

public class FindArrayElelment {
    public static int f(int num[],int key,int i){
        if (i== num.length){
            return -1;
        }
        if (num[i]==key){
            return i;
        }
        return f(num,key,i+1);
    }
    public static void main(String[] args) {
        int num[]={8,7,4,9,5,3,16,4,60};
        System.out.println(f(num,4,0));
    }
}
