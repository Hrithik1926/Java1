import java.util.*;
public class Exercise1 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number");
        int num=sc.nextInt();
        if (num>0){
            System.out.println("Greater than 0.");
        }else{
            System.out.println("Less than 0.");
        }

    }
}
