package Practice1;
import java.util.*;
public class Q4 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);



        int n[]=new int[3];
        System.out.println(n.length);

       for ( int i=0;i<n.length;i++){
           n[i]=sc.nextInt();

       }
       double sum=0;
        for (int i: n) {
            sum += i;
        }

        double average=sum/n.length;
        System.out.println(average);


    }
}
