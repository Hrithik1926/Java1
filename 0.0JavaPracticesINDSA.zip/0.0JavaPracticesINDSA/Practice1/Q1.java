package Practice1;
import java.util.*;
//Area of Circle
public class Q1 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the Radius");
        int r=sc.nextInt();
        double area=3.14*r*r;
        System.out.println(area);
    }
}
