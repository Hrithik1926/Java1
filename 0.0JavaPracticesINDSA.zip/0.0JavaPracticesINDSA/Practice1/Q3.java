package Practice1;
import java.util.*;
public class Q3 {
    public static void main(String[] args) {
        int count=0;
        for (int i = 9; i < 100; i++) {

            //For Odd Number
            if (i % 2 != 0){

                System.out.println(i+" "+count);
                count++;

            }
//            System.out.println(" "+count);


        }
        System.out.println("***********************************");
        //For Even
        for (int i = 9; i < 100; i++) {
            //For Odd Number
            if (i % 2 == 0)
                System.out.println(i);

        }
    }
}
