public class TrappedWater {
    public static int trappedRainWater(int height[]){
int n= height.length;
        //Calculate the MaxLeft boundary -array
        int leftMax[]=new int[n];
        leftMax[0]=height[0];
        for (int i=1;i<n;i++){
leftMax[i]=Math.max(height[i],leftMax[i-1] );
        }
        //Calculate the MaxRight boundary -array
        int rigthMax[]=new int[n];
        rigthMax[n-1]=height[n-1];

        for (int i=n-2;i>=0;i--){
          rigthMax[i]=Math.max(height[i],rigthMax[i+1]);
        }
        int trappedWater=0;
        //loop
        for (int i=0;i<n;i++){
            //Calculate the minimum of leftmax and rightmax
            int waterLevel=Math.min(leftMax[i],rigthMax[i]);
            //trapped water
            trappedWater+=waterLevel-height[i];
        }
return trappedWater;
    }
    public static void main(String[] args) {
        int height[]={5,2,0,7,9,3,4,8,1};
        System.out.println(trappedRainWater(height));
    }
}
