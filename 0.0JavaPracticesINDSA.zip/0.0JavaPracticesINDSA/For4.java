public class For4 {
    public static void main(String[] args) {
        long n=1586354568465446512L;
while (n>0){
    long lastDigit=n%10;
    System.out.print(lastDigit+" ");
    n=n/10;


}
        System.out.println(n+" ");
    }
}
