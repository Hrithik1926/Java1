public class TypeConversion {
    public static void main(String[] args) {
        int marks=15454;
        float m=marks;
        double n=m;
        byte a=54;
        short b=a;
        float c=b;
        double d=c;
int e=(int)c;
        System.out.println(b);
        System.out.println(e);
        System.out.println(c);
        System.out.println(d);
        System.out.println(n);
        System.out.println(marks);
        System.out.println(m);
    }
}
