package Practice7;

import java.util.Scanner;

public class p3 {
    public  static int sumOfNumber(){
        Scanner sc=new Scanner(System.in);
        int num=sc.nextInt();
        int sum=0;
        for (int i=0;i<=num;i++){
            sum+=i;
        }
        return sum;
    }
    public static void main(String[] args) {
        System.out.println(sumOfNumber());

    }
}
