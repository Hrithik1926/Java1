package Practice7;

public class Method {

public static void F1(){
    int math=99;
    int p=88;
    int ch=95;
    double averge=((math+p+ch)/7);
    System.out.println(averge);
}
    public static void main(String[] args) {
F1();


    }
}
