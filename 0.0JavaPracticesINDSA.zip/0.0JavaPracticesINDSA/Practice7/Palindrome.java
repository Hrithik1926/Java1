package Practice7;

import java.util.Scanner;

public class Palindrome {
    public static boolean isPalindrome(){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number;");
        int num=sc.nextInt();
        String str=Integer.toString(num);
        int n=str.length();
        for (int i=0;i<n/2;i++){
            if (str.charAt(i)==str.charAt(n-1-i)){
                return true;
            }
        }
        return false;
    }
    public static void main(String[] args) {
//        isPalindrome();
        System.out.println(isPalindrome());

    }
}
