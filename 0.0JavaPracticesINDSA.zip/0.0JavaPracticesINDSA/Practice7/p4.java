package Practice7;

import java.util.Scanner;

public class p4 {
    public static int sumNum(int num){
        Scanner sc=new Scanner(System.in);
//        int n=sc.nextInt();
        int total=0;
        while(num>0){
            int r=num%10;
            total+=r;
         int u= num/10;
        }

        return total;

    }


    public static void main(String[] args) {
        System.out.println(sumNum(2356));
    }
}
