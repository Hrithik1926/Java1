package Practice7;

public class p12 {
        public static void main(String[] args) {
            int number = 12345;
            int sum = sumOfDigits(number);
            System.out.println("Sum of digits in " + number + " is " + sum);
        }

        public static int sumOfDigits(int n) {
            int total = 0;
            while (n > 0) {
                int digit = n % 10;
                total += digit;
                n /= 10;
            }
            return total;
        }
    }


