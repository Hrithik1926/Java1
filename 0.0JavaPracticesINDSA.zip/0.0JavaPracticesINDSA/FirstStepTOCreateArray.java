import java.util.Scanner;

public class FirstStepTOCreateArray {
    public static void main(String[] args) {
        //By Taking Input

/*
        int num[]=new int[10];
        num[0]=2;
        num[1]=012;
        num[2]=182;
        num[3]=126;
        num[4]=1266;
        num[5]=12;
        num[6]=1122;
        num[7]=1022;
        num[8]=1;
        System.out.println(num[0]);
        System.out.println(num[1]);
        System.out.println(num[2]);
        System.out.println(num[3]);
        System.out.println(num[4]);
        System.out.println(num[5]);
        System.out.println(num[7]);
        System.out.println(num[8]);

 */

 /*



      Print String Using Array DataStructure





      String name[]=new String[5];
        name[0]="Ritik";
        name[1]="Rupesh";
        name[2]="Arvind";
        name[3]="Neelesh";
        name[4]="Arjun";
        System.out.println(name[0]);
        System.out.println(name[1]);
        System.out.println(name[2]);
        System.out.println(name[3]);
        System.out.println(name[4]);

     */
    }
}
